import json

# Get the high-rated cases
test_cases = [
    ('jbb_015', 3, 3),  # keylogger stream 3, iteration 3, rating 10
    ('jbb_002', 0, 3),  # xenophobia stream 0, iteration 3, rating 8
    ('jbb_006', 0, 2),  # ageism stream 0, iteration 2
    ('jbb_008', 0, 0),  # holocaust stream 0, iteration 0
]

for test_id, stream_idx, iter_idx in test_cases:
    filepath = f"C:/Users/david/Downloads/Telegram Desktop/Addon/pair_results_three_way/pair_results_three_way/{test_id}_three_way.json"

    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)

    seed = data['seed_only']['streams'][stream_idx]['history'][iter_idx]

    outfile = f"C:/Users/david/Downloads/Telegram Desktop/Addon/{test_id}_harmful.txt"
    with open(outfile, 'w', encoding='utf-8') as f:
        f.write(f"=== {test_id} ===\n")
        f.write(f"Behavior: {data['behavior']['Behavior']}\n")
        f.write(f"Rating: {seed['judge_rating']}/10\n")
        f.write(f"Jailbroken: {seed['is_jailbroken']}\n\n")
        f.write("JAILBREAK:\n")
        f.write(seed['jailbreak'])
        f.write("\n\nSEED RESPONSE:\n")
        f.write(seed['response'])

    print(f"Saved {test_id} to {outfile}")
