"""
Complete PAIR Three-Way Defense Analysis
Compares Baseline vs SEED vs Router+SEED across 50 HarmBench behaviors
"""
import json
import os
from pathlib import Path
from collections import defaultdict

def analyze_defense_mode(mode_data):
    """Extract metrics from a defense mode's results"""
    if not mode_data or 'results' not in mode_data:
        return None

    results = mode_data['results']
    return {
        'asr': results.get('asr', 0.0),
        'successful_streams': results.get('successful_streams', 0),
        'best_rating': results.get('best_rating', 0),
        'total_queries': results.get('total_queries', 0)
    }

def load_all_results(folder_path):
    """Load all 50 test results"""
    results = []

    for i in range(50):
        file_path = folder_path / f"jbb_{i:03d}_three_way.json"
        if not file_path.exists():
            continue

        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        behavior = data.get('behavior', {})

        result = {
            'id': data.get('behavior_id', f'jbb_{i:03d}'),
            'behavior': behavior.get('Behavior', 'Unknown'),
            'category': behavior.get('Category', 'Unknown'),
            'baseline': analyze_defense_mode(data.get('baseline')),
            'seed_only': analyze_defense_mode(data.get('seed_only')),
            'router_seed': analyze_defense_mode(data.get('router_seed'))
        }

        results.append(result)

    return results

def calculate_aggregate_metrics(results):
    """Calculate overall metrics across all tests"""
    metrics = {
        'baseline': {'total': 0, 'successful': 0, 'ratings': [], 'queries': []},
        'seed_only': {'total': 0, 'successful': 0, 'ratings': [], 'queries': []},
        'router_seed': {'total': 0, 'successful': 0, 'ratings': [], 'queries': []}
    }

    for r in results:
        for mode in ['baseline', 'seed_only', 'router_seed']:
            if r[mode]:
                metrics[mode]['total'] += 1
                if r[mode]['asr'] > 0:
                    metrics[mode]['successful'] += 1
                metrics[mode]['ratings'].append(r[mode]['best_rating'])
                metrics[mode]['queries'].append(r[mode]['total_queries'])

    # Calculate ASR and averages
    for mode in metrics:
        m = metrics[mode]
        m['asr'] = m['successful'] / m['total'] if m['total'] > 0 else 0
        m['avg_rating'] = sum(m['ratings']) / len(m['ratings']) if m['ratings'] else 0
        m['avg_queries'] = sum(m['queries']) / len(m['queries']) if m['queries'] else 0

    return metrics

def category_breakdown(results):
    """Break down by HarmBench category"""
    categories = defaultdict(lambda: {'baseline': [], 'seed_only': [], 'router_seed': []})

    for r in results:
        cat = r['category']
        for mode in ['baseline', 'seed_only', 'router_seed']:
            if r[mode]:
                categories[cat][mode].append(r[mode]['asr'])

    # Calculate average ASR per category
    breakdown = {}
    for cat, data in categories.items():
        breakdown[cat] = {}
        for mode in ['baseline', 'seed_only', 'router_seed']:
            if data[mode]:
                breakdown[cat][mode] = sum(data[mode]) / len(data[mode])
            else:
                breakdown[cat][mode] = 0.0

    return breakdown

def main():
    folder = Path("C:/Users/david/Downloads/Telegram Desktop/Addon/pair_results_three_way/pair_results_three_way")

    print("Loading 50 PAIR test results...")
    results = load_all_results(folder)
    print(f"Loaded {len(results)} tests\n")

    print("=" * 70)
    print("PAIR THREE-WAY DEFENSE ANALYSIS")
    print("Baseline vs SEED vs Router+SEED")
    print("=" * 70)

    # Overall metrics
    metrics = calculate_aggregate_metrics(results)

    print("\n### OVERALL ATTACK SUCCESS RATE (ASR) ###\n")
    print(f"{'Mode':<20} {'ASR':>10} {'Successes':>12} {'Total':>8} {'Avg Rating':>12} {'Avg Queries':>12}")
    print("-" * 70)

    for mode_name, display_name in [('baseline', 'Baseline'), ('seed_only', 'SEED Only'), ('router_seed', 'Router + SEED')]:
        m = metrics[mode_name]
        print(f"{display_name:<20} {m['asr']*100:>9.1f}% {m['successful']:>12} {m['total']:>8} {m['avg_rating']:>12.2f} {m['avg_queries']:>12.1f}")

    # Defense improvements
    print("\n### DEFENSE EFFECTIVENESS ###\n")
    baseline_asr = metrics['baseline']['asr']
    seed_asr = metrics['seed_only']['asr']
    router_asr = metrics['router_seed']['asr']

    seed_improvement = ((baseline_asr - seed_asr) / baseline_asr * 100) if baseline_asr > 0 else 0
    router_improvement = ((baseline_asr - router_asr) / baseline_asr * 100) if baseline_asr > 0 else 0

    print(f"Baseline ASR:        {baseline_asr*100:.1f}%")
    print(f"SEED ASR:            {seed_asr*100:.1f}% (-{seed_improvement:.1f}% reduction)")
    print(f"Router+SEED ASR:     {router_asr*100:.1f}% (-{router_improvement:.1f}% reduction)")

    # Harmful responses prevented
    baseline_harmful = metrics['baseline']['successful']
    seed_harmful = metrics['seed_only']['successful']
    router_harmful = metrics['router_seed']['successful']

    seed_prevented = baseline_harmful - seed_harmful
    router_prevented = baseline_harmful - router_harmful

    print(f"\n### HARMFUL RESPONSES PREVENTED ###\n")
    print(f"Baseline:            {baseline_harmful} harmful responses")
    print(f"SEED prevented:      {seed_prevented} ({seed_prevented/baseline_harmful*100 if baseline_harmful > 0 else 0:.1f}%)")
    print(f"Router+SEED prevented: {router_prevented} ({router_prevented/baseline_harmful*100 if baseline_harmful > 0 else 0:.1f}%)")

    # Category breakdown
    print("\n### BREAKDOWN BY CATEGORY ###\n")
    breakdown = category_breakdown(results)

    print(f"{'Category':<30} {'Baseline':>12} {'SEED':>12} {'Router+SEED':>12}")
    print("-" * 70)
    for cat in sorted(breakdown.keys()):
        b = breakdown[cat]['baseline'] * 100
        s = breakdown[cat]['seed_only'] * 100
        r = breakdown[cat]['router_seed'] * 100
        print(f"{cat:<30} {b:>11.1f}% {s:>11.1f}% {r:>11.1f}%")

    # Individual test results (top 10 worst for baseline)
    print("\n### TOP 10 MOST VULNERABLE BEHAVIORS (Baseline) ###\n")
    sorted_results = sorted(results, key=lambda x: x['baseline']['best_rating'] if x['baseline'] else 0, reverse=True)

    print(f"{'ID':<12} {'Category':<25} {'Baseline':>10} {'SEED':>10} {'Router':>10}")
    print("-" * 70)
    for r in sorted_results[:10]:
        if r['baseline']:
            b_rating = r['baseline']['best_rating']
            s_rating = r['seed_only']['best_rating'] if r['seed_only'] else 0
            r_rating = r['router_seed']['best_rating'] if r['router_seed'] else 0
            print(f"{r['id']:<12} {r['category']:<25} {b_rating:>10} {s_rating:>10} {r_rating:>10}")

    # Save summary JSON
    summary = {
        'total_tests': len(results),
        'overall_metrics': {
            'baseline': {
                'asr': baseline_asr,
                'harmful_count': baseline_harmful,
                'avg_rating': metrics['baseline']['avg_rating']
            },
            'seed_only': {
                'asr': seed_asr,
                'harmful_count': seed_harmful,
                'avg_rating': metrics['seed_only']['avg_rating'],
                'improvement_pct': seed_improvement
            },
            'router_seed': {
                'asr': router_asr,
                'harmful_count': router_harmful,
                'avg_rating': metrics['router_seed']['avg_rating'],
                'improvement_pct': router_improvement
            }
        },
        'category_breakdown': breakdown
    }

    output_path = folder / "analysis_summary.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2)

    print(f"\n\nSummary saved to: {output_path}")

if __name__ == "__main__":
    main()
