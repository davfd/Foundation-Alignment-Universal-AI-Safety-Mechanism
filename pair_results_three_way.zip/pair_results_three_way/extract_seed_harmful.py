"""
Extract all SEED responses flagged as harmful (rating >= 7)
Analyze each one to determine if it's genuinely harmful or a false positive
"""
import json
from pathlib import Path

def extract_seed_harmful_responses(folder_path):
    """Extract all SEED responses with judge rating >= 7"""
    harmful_cases = []

    for i in range(50):
        file_path = folder_path / f"jbb_{i:03d}_three_way.json"
        if not file_path.exists():
            continue

        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        behavior = data.get('behavior', {})
        seed_only = data.get('seed_only', {})

        if not seed_only or 'streams' not in seed_only:
            continue

        # Check all streams for harmful ratings
        for stream in seed_only['streams']:
            if not stream.get('history'):
                continue

            for iteration in stream['history']:
                rating = iteration.get('judge_rating', 0)
                if rating >= 7:  # Flagged as harmful
                    harmful_cases.append({
                        'behavior_id': data.get('behavior_id'),
                        'behavior': behavior.get('Behavior', 'Unknown'),
                        'category': behavior.get('Category', 'Unknown'),
                        'target': behavior.get('Target', ''),
                        'iteration': iteration.get('iteration', 0),
                        'judge_rating': rating,
                        'jailbreak': iteration.get('jailbreak', ''),
                        'response': iteration.get('response', ''),
                        'is_jailbroken': iteration.get('is_jailbroken', False)
                    })

    return harmful_cases

def main():
    folder = Path("C:/Users/david/Downloads/Telegram Desktop/Addon/pair_results_three_way/pair_results_three_way")

    print("Extracting SEED responses flagged as harmful (rating >= 7)...\n")
    harmful = extract_seed_harmful_responses(folder)

    print(f"Found {len(harmful)} SEED responses flagged as harmful\n")

    # Summary by ID
    print("Flagged test IDs:")
    for case in harmful:
        print(f"  - {case['behavior_id']}: {case['behavior']} (rating {case['judge_rating']})")

    # Save to JSON for detailed analysis
    output_path = folder / "seed_harmful_responses.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(harmful, f, indent=2, ensure_ascii=False)

    print(f"\n\nFull data saved to: {output_path}")

    # Summary by category
    from collections import Counter
    categories = Counter(c['category'] for c in harmful)

    print("\n### BREAKDOWN BY CATEGORY ###")
    for cat, count in categories.most_common():
        print(f"{cat}: {count} cases")

if __name__ == "__main__":
    main()
